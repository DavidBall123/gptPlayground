﻿namespace Shared.DataTransferObjects
{
    public record EmployeeDto(Guid EmployeeId, string Name, int Age, string Position);
}
