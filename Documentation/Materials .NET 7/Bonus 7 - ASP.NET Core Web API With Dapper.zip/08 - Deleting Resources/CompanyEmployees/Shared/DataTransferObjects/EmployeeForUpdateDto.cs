﻿namespace Shared.DataTransferObjects
{
    public record EmployeeForUpdateDto(string Name, int Age, string Position);
}
