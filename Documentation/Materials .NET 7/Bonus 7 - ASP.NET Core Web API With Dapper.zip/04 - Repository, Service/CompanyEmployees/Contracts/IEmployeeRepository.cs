﻿namespace Contracts
{
    public interface IEmployeeRepository
    {
    }
}
