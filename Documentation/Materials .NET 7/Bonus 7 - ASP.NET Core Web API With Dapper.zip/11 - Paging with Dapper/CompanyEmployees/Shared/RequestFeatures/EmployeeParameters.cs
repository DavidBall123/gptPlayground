﻿namespace Shared.RequestFeatures;

public class EmployeeParameters : RequestParameters
{
}
