﻿namespace Shared.DataTransferObjects;

public record EmployeeForCreationDto : EmployeeForManipulationDto;
