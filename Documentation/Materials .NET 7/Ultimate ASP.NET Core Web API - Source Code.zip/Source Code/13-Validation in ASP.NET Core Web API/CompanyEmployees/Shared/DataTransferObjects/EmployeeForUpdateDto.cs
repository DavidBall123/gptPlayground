﻿namespace Shared.DataTransferObjects;

public record EmployeeForUpdateDto : EmployeeForManipulationDto;
